#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L@@HOMEBREW_PREFIX@@/Cellar/libxml2/2.9.5/lib"
XML2_LIBS="-lxml2 -lz     -lm "
XML2_INCLUDEDIR="-I@@HOMEBREW_PREFIX@@/Cellar/libxml2/2.9.5/include/libxml2"
MODULE_VERSION="xml2-2.9.5"

