module Net
  class Telnet
    VERSION = "0.1.1"
  end
end
