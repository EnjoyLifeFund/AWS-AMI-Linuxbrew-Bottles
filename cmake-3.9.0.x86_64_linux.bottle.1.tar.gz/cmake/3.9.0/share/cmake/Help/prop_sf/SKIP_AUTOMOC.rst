SKIP_AUTOMOC
------------

Exclude the source file from :prop_tgt:`AUTOMOC` processing (for Qt projects).

For broader control see :prop_sf:`SKIP_AUTOGEN`
