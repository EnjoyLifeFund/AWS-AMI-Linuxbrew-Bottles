VS_XAML_TYPE
------------

Mark a XAML source file as a different type than the default ``Page``.
The most common usage would be to set the default App.xaml file as
ApplicationDefinition.
