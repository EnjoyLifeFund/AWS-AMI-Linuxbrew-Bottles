.. cmake-module:: ../../Modules/FindLTTngUST.cmake
