.. cmake-module:: ../../Modules/WriteBasicConfigVersionFile.cmake
