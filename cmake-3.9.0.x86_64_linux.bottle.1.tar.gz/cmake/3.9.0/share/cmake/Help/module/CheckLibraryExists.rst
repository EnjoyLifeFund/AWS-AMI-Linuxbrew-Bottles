.. cmake-module:: ../../Modules/CheckLibraryExists.cmake
