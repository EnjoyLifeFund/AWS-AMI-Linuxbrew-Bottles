VS_DEPLOYMENT_LOCATION
----------------------

Specifies the deployment location for a content source file with a Windows
Phone or Windows Store application when built with a Visual Studio generator.
This property is only applicable when using :prop_sf:`VS_DEPLOYMENT_CONTENT`.
The value represent the path relative to the app package and applies to all
configurations.
