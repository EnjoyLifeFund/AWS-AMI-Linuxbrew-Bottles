.. cmake-module:: ../../Modules/FindThreads.cmake
