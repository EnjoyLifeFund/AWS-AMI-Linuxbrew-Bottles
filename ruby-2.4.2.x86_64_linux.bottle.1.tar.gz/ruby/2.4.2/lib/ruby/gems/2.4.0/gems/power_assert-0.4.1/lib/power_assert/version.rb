module PowerAssert
  VERSION = "0.4.1"
end
